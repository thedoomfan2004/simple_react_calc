import Calc from './Calc'
import Bmi from './Bmi';
import Scientific from './Advanced';
import { Routes, Route, Link } from 'react-router-dom';
import arrow from '../assets/arrow.png'


function App() {

  return (
    <div className="w-screen relative bg-blue-100
     p-10 h-screen overflow-hidden flex flex-col items-center">
      <Routes>
        <Route path='/' element={<Calc />} />
        <Route path='/bmi' element={<Bmi />} />
        <Route path='/scientific' element={<Scientific />} />
      </Routes>
      <div className="absolute flex-col right-10 flex gap-2">
        <Link to='/' className='flex flex-col items-center
        text-sm rounded-xl bg-white text-black p-3'>
          Regular
          <br />
          <img src={arrow} alt="" className='w-3' />
          <img src={arrow} alt="" className='w-3 rotate-180' />
        </Link>
        <Link to='/bmi' className='flex flex-col items-center
        text-sm rounded-xl bg-white text-black p-3'>
          BMI
          <br />
          <img src={arrow} alt="" className='w-3' />
          <img src={arrow} alt="" className='w-3 rotate-180' />
        </Link>
        <Link to='/scientific' className='flex flex-col items-center
        text-sm rounded-xl top-20 bg-white text-black p-3'>
          Scientific
          <br />
          <img src={arrow} alt="" className='w-3' />
          <img src={arrow} alt="" className='w-3 rotate-180' />
        </Link>
        <button className='flex flex-col items-center
        text-sm rounded-xl top-40 bg-white text-black p-3'>
          Date
          <br />
          <img src={arrow} alt="" className='w-3' />
          <img src={arrow} alt="" className='w-3 rotate-180' />
        </button>
      </div> 
    </div>
  )
}

export default App
