import { useState } from 'react'

export default function Bmi() {


  const [bmi, setBmi] = useState<any>()  
  const [height, setHeight] = useState<any>()
  const [weight, setWeight] = useState<any>()

  function handleClick() {
    setBmi(Math.round(weight / ((height / 100) * (height / 100))))
  }


  function handleClear() {
    setBmi('')
    setHeight('')
    setWeight('')
  }

  function handleHeight(e: any) {
    setHeight(e.target.value)
  }

  function handleWeight(e: any) {
    setWeight(e.target.value)
  }

  return (
    <div className='w-72 shadow-2xl relative grid bg-black text-white
     rounded-xl grid-rows-4 grid-cols-4 md:w-3/4 gap-2 h-fit p-2'> 
      <div className="border w-full col-span-3 bg-transparent
       flex items-center rounded-xl p-2 text-sm h-14">
        Your BMI is: {bmi}
        {
        bmi < 18 && bmi > 2 ? ' Underweight' 
        : bmi >= 20 && bmi < 24 ? ' Normal' 
        : bmi >= 24 && bmi < 29 ? ' Overweight' 
        : bmi >= 30 ? ' Obese'
        : ''
        }
      </div>
      <button className='flex items-center justify-center cursor-pointer  text-white'>
        <div onClick={handleClear} className="h-14 flex items-center
         justify-center bg-red-700 hover:brightness-75 rounded-xl w-full">
            clear
        </div>
      </button>
      <input type="text" value={height} onChange={handleHeight} className='col-span-3 bg-transparent flex items-center p-2 rounded-xl border' 
      placeholder='Your Height' />
      <button value={'cm'}  className="hover:brightness-75 
      rounded-xl flex items-center justify-center bg-lime-600">
        CM
      </button>
      <input type="text" value={weight} onChange={handleWeight} className='col-span-3 bg-transparent flex items-center p-2 rounded-xl border' 
        placeholder='Your Weight' />
      <button value={'kg'} className="hover:brightness-75 rounded-xl 
      flex items-center justify-center bg-lime-600">
        KG
      </button>
      <button onClick={handleClick} className='col-span-4 hover:brightness-75 bg-orange-400 rounded-xl flex items-center justify-center'>
       Calculate
      </button>
      
    </div>
  )
}