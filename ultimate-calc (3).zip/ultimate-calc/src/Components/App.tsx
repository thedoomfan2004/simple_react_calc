import React, { useState } from 'react'
import Calc from './Calc'


function App() {

  return (
    <div className="w-screen bg-blue-100
     p-10 h-screen overflow-hidden flex flex-col items-center">
      <Calc />
    </div>
  )
}

export default App
