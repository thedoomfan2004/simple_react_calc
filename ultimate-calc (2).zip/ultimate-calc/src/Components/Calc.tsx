import React, {useState, useEffect} from 'react'

export default function Calc() {
  const numbers = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    0,
    '.',
  ]

  const functions = [
    '+',
    '-',
    '*',
    '/',
  ]

  let [num, setNum] = useState<string>('');
  let [savednum, setSavednum] = useState<string>('');
  let [func, setFunc] = useState<string>('');

  function handleClick(e: number | string) {
    setNum(num + e);
  }

  function handleFunction(e: string | number) {
    setSavednum(num);
    setFunc(e as string);
    setNum('');
  }

  function handleClear() {
    setNum('')
    setSavednum('')
    setFunc('')
  }

  function handleEqual() {
    switch (func) {
      case '+':
        setNum((+savednum + +num).toString());
        break;
      case '-':
        setNum((+savednum - +num).toString());
        break;
      case '/':
        setNum((+savednum / +num).toString());
        break;
      case '*':
        setNum((+savednum * +num).toString());
        break;
    }
  }

  return (
    <div className='w-72 grid bg-black text-white rounded-xl grid-rows-4 grid-cols-4 md:w-3/4 gap-2 h-2/4 p-2'> 
      <div className="flex col-start-1 justify-center items-center col-end-4">
        {/* <input className="border w-full flex items-center rounded-xl p-2 text-2xl h-14">
          {num}
        </input> */}
        <input type="text" className='border w-full bg-transparent flex items-center rounded-xl p-2 text-2xl h-14' value={num} placeholder='0' />
      </div>
      <button className='flex items-center justify-center cursor-pointer  text-white'>
        <div onClick={handleClear} className="h-14 flex items-center justify-center bg-red-700 hover:brightness-75 rounded-xl w-full">clear</div>
      </button>
      <div className="grid grid-cols-3 gap-2 row-span-3 col-span-3">
        {numbers.map(item => (
          <div onClick={() => handleClick(item)} className="flex shadow-sm shadow-white cursor-pointer
           hover:brightness-75 bg-blue-600 rounded-xl items-center justify-center">
            {item}
          </div>
        ))}
        <div className="flex items-center cursor-pointer hover:brightness-75
         rounded-xl text-white justify-center bg-orange-400" onClick={handleEqual}>
          <span className='text-xl'>=</span> 
        </div>

      </div>
      <div className="row-span-3 gap-2 grid grid-rows-4">
        {functions.map(item => (
          <div onClick={() => handleFunction(item)} className='flex items-center cursor-pointer
           hover:brightness-75 rounded-xl bg-lime-600 justify-center'>
            {item}
          </div>
        ))}
      </div>
    </div>
  )
}
