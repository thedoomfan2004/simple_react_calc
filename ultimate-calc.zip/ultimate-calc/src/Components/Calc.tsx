import React, {useState, useEffect} from 'react'

export default function Calc() {
  const numbers = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    0,
    '.',
  ]

  const functions = [
    '+',
    '-',
    '*',
    '/',
  ]

  let [num, setNum] = useState('')
  let [savednum, setSavednum] = useState('')
  let [func, setFunc] = useState('')
  let [answer, setAns] = useState('')

  function handleClick(e: number) {
    setNum(num += e)
  }

  function handeFunction(e: string  | number) {
    setSavednum(num)
    setFunc(e)
    setNum('')
  }

  function handleEqual() {
      switch(func) {
        case '+':
          setNum(+savednum + +num)
          break;
        case '-':
          setNum(+savednum - +num)
          break;
        case '/':
          setNum(+savednum / +num)
          break;
        case '*':
          setNum(+savednum * +num)
          break;
      }
    }

    useEffect(() => {
      function numberWithCommas(x: number) {
            var parts = x.toString().split(".");
            parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,".");
            return parts.join(",");
          }
      numberWithCommas(num)
    }, [num])

    
  
  
  return (
    <div className='w-72 grid bg-black text-white rounded-xl grid-rows-4 grid-cols-4 md:w-3/4 gap-2 h-2/4 p-2'> 
      <div className="flex col-start-1 justify-center items-center col-end-4">
        <div className="border w-full flex items-center rounded-xl p-2 text-2xl h-14">
          {num}
        </div>
      </div>
      <button className='flex items-center justify-center cursor-pointer  text-white'>
        <div className="h-14 flex items-center justify-center bg-red-400 hover:brightness-75 rounded-xl w-full">clear</div>
      </button>
      <div className="grid grid-cols-3 gap-2 row-span-3 col-span-3">
        {numbers.map(item => (
          <div onClick={() => handleClick(item)} className="flex shadow-sm shadow-white cursor-pointer
           hover:brightness-75 bg-blue-600 rounded-xl items-center justify-center">
            {item}
          </div>
        ))}
        <div className="flex items-center cursor-pointer hover:brightness-75
         rounded-xl text-white justify-center bg-orange-400" onClick={handleEqual}>
          <span className='text-xl'>=</span> 
        </div>

      </div>
      <div className="row-span-3 gap-2 grid grid-rows-4">
        {functions.map(item => (
          <div onClick={() => handeFunction(item)} className='flex items-center cursor-pointer
           hover:brightness-75 rounded-xl bg-lime-600 justify-center'>
            {item}
          </div>
        ))}
      </div>
    </div>
  )
}
